package com.example.experiencepixelkeyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class ExperienceKeyboardService : InputMethodService() {
    private var symbols = false
    private var caps = false
    private var language = "EN"
    private var hexagon: HexagonButton? = null
    private var toolsPanel: LinearLayout? = null
    private var panelVisible = false

    override fun onCreateInputView(): View {
        val prefs = getSharedPreferences("keyboard", MODE_PRIVATE)
        val dark = prefs.getBoolean("dark", true)
        val alpha = (prefs.getInt("transparency", 88) * 255 / 100).coerceIn(80, 255)
        val bg = if (dark) 0xFF17191F.toInt() else 0xFFE8EAF0.toInt()
        val key = if (dark) 0xFF30343D.toInt() else 0xFFFFFFFF.toInt()
        val fg = if (dark) 0xFFF5F5F7.toInt() else 0xFF202127.toInt()
        val accent = if (dark) 0xFFB9C7FF.toInt() else 0xFF435AA8.toInt()
        val font = if (prefs.getBoolean("customFont", true)) {
            try { Typeface.createFromAsset(assets, "artegrasoft-bold.ttf") } catch (_: Exception) { Typeface.DEFAULT }
        } else Typeface.DEFAULT

        val root = SwipeKeyboardLayout(this) { changeLanguage() }.apply {
            orientation = LinearLayout.VERTICAL
            setPadding(5, 5, 5, 7)
            setBackgroundColor((alpha shl 24) or (bg and 0x00FFFFFF))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 0, 4, 2)
        }
        val langLabel = TextView(this).apply {
            text = "$language  ·  свайп для смены"
            textSize = 11f
            setTextColor(fg)
            typeface = font
        }
        header.addView(langLabel, LinearLayout.LayoutParams(0, 34, 1f))

        toolsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(5, 5, 5, 5)
            background = rounded(if (dark) 0xFF292D35.toInt() else 0xFFFDFDFF.toInt(), 15f)
        }
        fun toolButton(title: String, action: () -> Unit) {
            val item = TextView(this).apply {
                text = title
                textSize = 13f
                setTextColor(fg)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(12, 8, 12, 8)
                setOnClickListener { action() }
            }
            toolsPanel?.addView(item)
        }
        toolButton("Буфер обмена") { pasteClipboard() }
        toolButton("Вставить") { pasteClipboard() }
        toolButton("Копировать всё") { currentInputConnection?.let {
            it.performContextMenuAction(android.R.id.selectAll)
            it.performContextMenuAction(android.R.id.copy)
        } }
        toolButton("Вырезать") { currentInputConnection?.performContextMenuAction(android.R.id.cut) }
        toolButton("Выбрать всё") { currentInputConnection?.performContextMenuAction(android.R.id.selectAll) }
        toolButton("Настройки") {
            panelVisible = false
            toolsPanel?.visibility = View.GONE
            startActivity(android.content.Intent(this, SettingsActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        header.addView(toolsPanel, LinearLayout.LayoutParams(170, LinearLayout.LayoutParams.WRAP_CONTENT))

        hexagon = HexagonButton(this, accent).apply {
            contentDescription = "Открыть инструменты"
            setOnClickListener {
                panelVisible = !panelVisible
                toolsPanel?.visibility = if (panelVisible) View.VISIBLE else View.GONE
                if (panelVisible) animate().translationX(-3f).setDuration(100).withEndAction {
                    animate().translationX(0f).setDuration(100).start()
                }.start()
            }
        }
        header.addView(hexagon, LinearLayout.LayoutParams(42, 38))
        root.addView(header)

        val rows = when {
            symbols -> listOf(
                listOf("1","2","3","4","5","6","7","8","9","0"),
                listOf("@","#","$","%","&","-","+","(",")","/"),
                listOf("=","*","\"","' ",":",";","!","?","⌫"),
                listOf("ABC",",","SPACE",".","↵")
            )
            language == "RU" -> listOf(
                listOf("й","ц","у","к","е","н","г","ш","щ","з","х"),
                listOf("ф","ы","в","а","п","р","о","л","д","ж","э"),
                listOf("⇧","я","ч","с","м","и","т","ь","б","ю","⌫"),
                listOf("?123",",","SPACE",".","↵")
            )
            else -> listOf(
                listOf("q","w","e","r","t","y","u","i","o","p"),
                listOf("a","s","d","f","g","h","j","k","l"),
                listOf("⇧","z","x","c","v","b","n","m","⌫"),
                listOf("?123",",","SPACE",".","↵")
            )
        }

        rows.forEachIndexed { index, row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { label ->
                val weight = when (label) {
                    "SPACE" -> 4.2f
                    "?123", "ABC", "⇧", "⌫", "↵" -> 1.25f
                    else -> 1.08f
                }
                val shown = when {
                    label == "SPACE" -> ""
                    caps && label.length == 1 -> label.uppercase()
                    else -> label
                }
                val tv = TextView(this).apply {
                    text = shown
                    textSize = if (label.length > 2) 13f else 19f
                    gravity = Gravity.CENTER
                    setTextColor(fg)
                    typeface = font
                    background = rounded(key, if (label == "SPACE") 11f else 13f)
                    val lp = LinearLayout.LayoutParams(0, if (index == 3) 50 else 48, weight)
                    lp.setMargins(1, 3, 1, 3)
                    layoutParams = lp
                    setOnClickListener { handleKey(label) }
                }
                line.addView(tv)
            }
            root.addView(line)
        }
        return root
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun changeLanguage() {
        language = if (language == "EN") "RU" else "EN"
        symbols = false
        requestKeyboardRefresh()
    }

    private fun handleKey(key: String) {
        val ic = currentInputConnection ?: return
        when (key) {
            "⇧" -> { caps = !caps; requestKeyboardRefresh() }
            "?123" -> { symbols = true; requestKeyboardRefresh() }
            "ABC" -> { symbols = false; requestKeyboardRefresh() }
            "⌫" -> ic.deleteSurroundingText(1, 0)
            "↵" -> {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
                if (action != null && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED)
                    ic.performEditorAction(action) else ic.commitText("\n", 1)
            }
            "SPACE" -> ic.commitText(" ", 1)
            "," -> ic.commitText(",", 1)
            "." -> ic.commitText(".", 1)
            else -> {
                val text = if (caps) key.uppercase() else key
                ic.commitText(text, 1)
                hexagon?.pulse()
            }
        }
    }

    private fun pasteClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = clipboard.primaryClip
        val text = clip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)
        if (!text.isNullOrEmpty()) currentInputConnection?.commitText(text, 1)
    }

    private fun requestKeyboardRefresh() {
        setInputView(onCreateInputView())
    }
}

private class SwipeKeyboardLayout(
    context: Context,
    private val onSwipe: () -> Unit
) : LinearLayout(context) {
    private var downX = 0f
    private var downY = 0f
    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            downX = event.x
            downY = event.y
        } else if (event.action == MotionEvent.ACTION_UP) {
            val dx = event.x - downX
            val dy = event.y - downY
            if (kotlin.math.abs(dx) > 95f && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.4f) {
                onSwipe()
                return true
            }
        }
        return super.dispatchTouchEvent(event)
    }
}

private class HexagonButton(context: Context, private val tint: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = tint
        style = Paint.Style.STROKE
        strokeWidth = 3.2f
        strokeJoin = Paint.Join.ROUND
    }
    private val gearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = tint
        textAlign = Paint.Align.CENTER
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
    }
    init { spinContinuously() }

    private fun spinContinuously() {
        animate().rotationBy(360f).setDuration(5000)
            .setInterpolator(LinearInterpolator())
            .withEndAction {
                rotation = 0f
                spinContinuously()
            }.start()
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = minOf(width, height) * 0.39f
        val path = Path()
        for (i in 0..5) {
            val angle = Math.toRadians((i * 60.0) - 30.0)
            val x = cx + radius * kotlin.math.cos(angle).toFloat()
            val y = cy + radius * kotlin.math.sin(angle).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        canvas.drawPath(path, paint)
        canvas.drawText("⚙", cx, cy + 6f, gearPaint)
    }
    fun pulse() {
        animate().cancel()
        scaleX = 1f
        scaleY = 1f
        animate().scaleX(1.28f).scaleY(1.28f).setDuration(75).withEndAction {
            animate().scaleX(1f).scaleY(1f).setDuration(110).start()
        }.start()
    }
}
