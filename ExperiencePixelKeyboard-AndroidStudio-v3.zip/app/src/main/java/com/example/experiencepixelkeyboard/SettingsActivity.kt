package com.example.experiencepixelkeyboard

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class SettingsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("keyboard", MODE_PRIVATE)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF5F5F7.toInt())
        }
        page.addView(TextView(this).apply {
            text = "Experience Pixel Keyboard"
            textSize = 25f
            setTextColor(0xFF17171B.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        page.addView(TextView(this).apply {
            text = "Минимализм Pixel · мягкие формы One UI · быстрый набор"
            textSize = 14f
            setTextColor(0xFF65656D.toInt())
            setPadding(0, 8, 0, 24)
        })

        val enable = Button(this).apply {
            text = "Включить клавиатуру"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        page.addView(enable)
        val choose = Button(this).apply {
            text = "Выбрать клавиатуру"
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        page.addView(choose)

        page.addView(section("Внешний вид"))
        val transparency = SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("transparency", 88)
            setOnSeekBarChangeListener(simpleListener { prefs.edit().putInt("transparency", it).apply() })
        }
        page.addView(label("Непрозрачность фона"))
        page.addView(transparency)

        val blur = Switch(this).apply {
            text = "Эффект матового стекла (если поддерживается системой)"
            isChecked = prefs.getBoolean("blur", true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("blur", checked).apply() }
        }
        page.addView(blur)

        val dark = Switch(this).apply {
            text = "Тёмная тема"
            isChecked = prefs.getBoolean("dark", true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("dark", checked).apply() }
        }
        page.addView(dark)

        page.addView(section("Шрифт"))
        val font = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            val system = RadioButton(this@SettingsActivity).apply { text = "Системный"; id = 1 }
            val custom = RadioButton(this@SettingsActivity).apply { text = "ArtegraSoft Bold (встроенный)"; id = 2 }
            addView(system); addView(custom)
            check(if (prefs.getBoolean("customFont", true)) 2 else 1)
            setOnCheckedChangeListener { _, id -> prefs.edit().putBoolean("customFont", id == 2).apply() }
        }
        page.addView(font)

        page.addView(TextView(this).apply {
            text = "Высота клавиатуры и тактильный отклик будут доступны в следующих настройках. Это стартовая сборка."
            textSize = 13f
            setTextColor(0xFF777780.toInt())
            setPadding(0, 24, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(page) })
    }

    private fun section(s: String) = TextView(this).apply {
        text = s; textSize = 18f; setTextColor(0xFF25252B.toInt())
        setPadding(0, 26, 0, 10); typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 14f; setTextColor(0xFF55555D.toInt()); setPadding(0, 12, 0, 4)
    }
    private fun simpleListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { onChange(progress) }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }
}
